
//This iteration is using code from this youtube tutorial: https://www.youtube.com/watch?v=RrjOp2tJ3VE
//In the tutorial code, only the stroke colour changes when the speaker speaks a colour, however, in my code, I change the background colour of the screen and the stroke turns white


let Xpos = 0, Xv = 0, Ypos = 0, Yv = 0, Stop = false;

var SpeechRec = new p5.SpeechRec();

SpeechRec.continuous = true;
SpeechRec.interimResults = true;
//let song;

//function preload() {
//    
//     song = loadSound('song.mp3');
//}


function setup() {
    
    createCanvas(windowWidth, windowHeight);
   // let voice = new p5.Speech();
   // voice.speak('Hi Anushka');
    strokeWeight(4);
    background(255);    
    SpeechRec.start();
    SpeechRec.onResult = showResult;
    
}

function draw() {
    
    point(width/2 + Xpos, height/2 + Ypos);
    
   if (Stop == false) {
        Xpos = Xpos + Xv;
        Ypos = Ypos + Yv;
    }
}

function showResult() {
    
   // console.log(SpeechRec.resultString);
    
    switch(SpeechRec.resultString) {
        case "Stop": case "stop":
      Stop = true
      Xv = 0
      Yv = 0
      break
    case "start":
      Stop = false
      break
    case "clear":
      background(255)
      break
    case "restart":
      Xv = 0
      Xpos = 0
      Yv = 0
      Ypos = 0
      Stop = false
      background(255)
      break
    case "red":
      stroke(255)
            background(255, 0, 0); 
      break
    case "orange":
      stroke(0);
            background(255, 127.5, 0); 
      break
    case "yellow":
      stroke(0)
            background(252, 239, 20, 99);
      break
    case "green":
      stroke(255)
      break
    case "blue":
      stroke(255)
            background(0, 0, 255); 
      break
    case "purple":
      stroke(255)
             background(235, 20, 248);
      break
    case "black":
      stroke(255)
              background(0);
      break
    case "up":
      Yv = -1
      Xv = 0
      break
    case "down":
      Yv = 1
      Xv = 0
      break
    case "left":
      Yv = 0
      Xv = -1
      break
    case "right":
      Yv = 0
      Xv = 1
      break
            
           
            
    }
}