function setup() {
  
    noCanvas();
    let lang = navigator.language || 'en-US';
let speechRec = new p5.SpeechRec(lang, gotSpeech);
    speechRec.start();
    
    let continuous = true;
    let interim = false;
speechRec.start(continuous, interim);
    
    function gotSpeech() {
        
        if (speechRec.resultValue) {
            
            createP(speechRec.resultString);
        }
        
        //console.log(speechRec);
    }
    
}

function draw() {
  // put drawing code here
}