
//This iteration is using code from this youtube tutorial: https://www.youtube.com/watch?v=RrjOp2tJ3VE



let Xpos = 0, Xv = 0, Ypos = 0, Yv = 0, Stop = false;

var SpeechRec = new p5.SpeechRec();

SpeechRec.continuous = true;
SpeechRec.interimResults = true;

function setup() {
    
    createCanvas(windowWidth, windowHeight);
   // let voice = new p5.Speech();
   // voice.speak('Hi Anushka');
    strokeWeight(4);
    background(255);    
    SpeechRec.start();
    SpeechRec.onResult = showResult;
    
}

function draw() {
    
    point(width/2 + Xpos, height/2 + Ypos);
    
   if (Stop == false) {
        Xpos = Xpos + Xv;
        Ypos = Ypos + Yv;
    }
}

function showResult() {
    
   // console.log(SpeechRec.resultString);
    
    switch(SpeechRec.resultString) {
        case "up":
            Yv = -1;
            Xv = 0;
            break;
    }
}