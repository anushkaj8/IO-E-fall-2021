let song;
var SpeechRec = new p5.SpeechRec();

SpeechRec.continuous = true;
SpeechRec.interimResults = true;

function preload() {
    
     song = loadSound('assets/assets_sounds_squiggle.mp3');
}


function setup() {
 
  createCanvas(720, 200);
  background(255, 0, 0);
    SpeechRec.start();
    SpeechRec.onResult = showResult;
}


function showResult() {
    
   // console.log(SpeechRec.resultString);
    
    switch(SpeechRec.resultString) {
        case "play":
            song.play()
            break
            case "go":
            song.play()
            break
            case "stop":
            song.stop()
            break
    }
}
            
            
//            
//function mousePressed() {
//  if (song.isPlaying()) {
//    // .isPlaying() returns a boolean
//    song.stop();
//    background(255, 0, 0);
//  } else {
//    song.play();
//    background(0, 255, 0);
//  }
//}
